# Trainingsplan Tracker Android Studio Projekt

Android Studio Projekt für den Gym-Tracker mit lokalem Fortschritts-Tracking.

## Neu in dieser Version

- In der Hauptansicht wird immer nur eine Übung mit allen Details angezeigt.
- Alle anderen Übungen erscheinen darunter nur als kompakte Karten mit Übungsnamen.
- Es wird kein Plan-Gewicht mehr in der Trainingsansicht angezeigt.
- Das Gewichtsfeld übernimmt den letzten geloggten Wert als Startwert.
- Zusätzliche kleinere Felder für Warm-up-Gewicht und Warm-up-WDH mit Werten vom letzten Training.
- Keine Done-Checkbox mehr oben in der Übungskarte.
- Der Abschluss-Button heißt jetzt **Fertig**.
- Beim Drücken auf **Fertig** blendet sich die aktuelle Übungskarte mit Animation aus und die nächste Übung wird groß angezeigt.
- Setup-Seite bleibt über das Zahnrad erreichbar.
- Übungen können im Setup weiterhin bearbeitet, gelöscht und hinzugefügt werden.
- Beim Wechsel zwischen Trainingstagen blenden alle Karten kurz aus und der neue Tag blendet weich ein.

## Öffnen

ZIP entpacken und den Ordner in Android Studio über **File → Open** öffnen.

## Build

In Android Studio: **Build → Build APK(s)** oder **Run** auf einem verbundenen Android Gerät.


Update: Zahlenkeyboard
- Gewicht, Warm-up-Gewicht, WDH und Warm-up-WDH öffnen jetzt mit numerischem Keyboard.
- Textfelder ohne Zahleneingabe bleiben normale Textfelder.


Update: Die unteren Buttons für Tag speichern/Heute/Timer wurden entfernt. Eingaben speichern automatisch; der Pausentimer bleibt über den Button in der aktiven Übung erreichbar.


## Version 1.2 – Import/Export unten + Firebase Sync vorbereitet

Neu:
- Der Import/Export-Button oben wurde entfernt.
- Import/Export liegt jetzt als Karte ganz unten in den Einstellungen.
- Firebase/Firestore-Sync ist vorbereitet: Trage in den Einstellungen deine Firebase-Web-App-Daten ein und aktiviere den Sync.
- Die App speichert weiterhin lokal automatisch bei jeder Eingabe. Wenn Firebase verbunden ist, wird zusätzlich automatisch in Firestore gespeichert.

### Firebase kurz einrichten
1. In Firebase ein Projekt erstellen.
2. Eine Web-App im Firebase-Projekt anlegen.
3. Firestore Database aktivieren.
4. Die Web-App-Konfigurationswerte in der App unter Einstellungen unten eintragen: API Key, Auth Domain, Project ID, App ID und optional Sender ID / Storage Bucket.
5. Eine eindeutige Sync-ID wählen, z. B. `ju_training_main`.
6. In Firestore muss Schreiben/Lesen für deine gewählte Nutzung erlaubt sein. Für private Nutzung idealerweise später mit Auth absichern.

Die Trainingsdaten werden im Firestore-Pfad `gym_tracker_sync/<Sync-ID>` gespeichert.
