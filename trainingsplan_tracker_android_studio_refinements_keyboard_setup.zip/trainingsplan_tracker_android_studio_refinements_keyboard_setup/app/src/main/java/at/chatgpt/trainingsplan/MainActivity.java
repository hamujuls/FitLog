package at.chatgpt.trainingsplan;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JsResult;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.app.AlertDialog;
import android.view.Window;
import android.view.View;
import android.view.WindowInsets;
import android.os.Build;
import android.graphics.Color;
import android.widget.Toast;
import android.content.Intent;
import android.content.ContentValues;
import android.net.Uri;
import android.provider.MediaStore;
import android.os.Environment;
import android.content.Context;
import android.os.VibrationEffect;
import android.os.Vibrator;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;
    private static final int CREATE_BACKUP_REQUEST_CODE = 1002;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingBackupData;
    private String pendingBackupFilename;

    public class BackupBridge {
        @JavascriptInterface
        public void saveBackup(String data, String filename) {
            runOnUiThread(() -> {
                String safeName = sanitizeFilename(filename == null || filename.trim().isEmpty()
                        ? "trainingsplan_tracker_backup.json"
                        : filename.trim());
                pendingBackupData = String.valueOf(data);
                pendingBackupFilename = safeName;
                try {
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.putExtra(Intent.EXTRA_TITLE, safeName);
                    startActivityForResult(intent, CREATE_BACKUP_REQUEST_CODE);
                } catch (Exception e) {
                    pendingBackupData = null;
                    pendingBackupFilename = null;
                    Toast.makeText(MainActivity.this, "Speicherort-Auswahl konnte nicht geöffnet werden.", Toast.LENGTH_LONG).show();
                }
            });
        }

        private String sanitizeFilename(String name) {
            String cleaned = name.replaceAll("[^a-zA-Z0-9._-]", "_");
            if (!cleaned.toLowerCase().endsWith(".json")) cleaned += ".json";
            return cleaned;
        }
    }

    public class FeedbackBridge {
        @JavascriptInterface
        public void vibrate(int milliseconds) {
            runOnUiThread(() -> {
                try {
                    Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    if (vibrator == null) return;
                    int ms = Math.max(1, Math.min(milliseconds, 5000));
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
                    } else {
                        vibrator.vibrate(ms);
                    }
                } catch (Exception ignored) { }
            });
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.parseColor("#0b0f14"));
        window.setNavigationBarColor(Color.parseColor("#0b0f14"));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(true);
        }

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.addJavascriptInterface(new BackupBridge(), "AndroidBackup");
        webView.addJavascriptInterface(new FeedbackBridge(), "AndroidFeedback");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (dialog, which) -> result.confirm())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("Ja", (dialog, which) -> result.confirm())
                        .setNegativeButton("Nein", (dialog, which) -> result.cancel())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback, WebChromeClient.FileChooserParams fileChooserParams) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;
                Intent intent = fileChooserParams.createIntent();
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST_CODE);
                } catch (Exception e) {
                    MainActivity.this.filePathCallback = null;
                    Toast.makeText(MainActivity.this, "Dateiauswahl konnte nicht geöffnet werden.", Toast.LENGTH_LONG).show();
                    return false;
                }
                return true;
            }
        });
        webView.setFitsSystemWindows(true);
        webView.setOnApplyWindowInsetsListener((View v, WindowInsets insets) -> {
            int top;
            int bottom;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                top = bars.top;
                bottom = bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(0, top, 0, bottom);
            return insets;
        });
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CREATE_BACKUP_REQUEST_CODE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupData != null) {
                try (OutputStream outputStream = getContentResolver().openOutputStream(data.getData())) {
                    if (outputStream == null) throw new Exception("Datei konnte nicht geöffnet werden.");
                    outputStream.write(pendingBackupData.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "Backup gespeichert: " + (pendingBackupFilename == null ? "Datei" : pendingBackupFilename), Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Export fehlgeschlagen: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
            pendingBackupData = null;
            pendingBackupFilename = null;
            return;
        }
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK) {
                results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
