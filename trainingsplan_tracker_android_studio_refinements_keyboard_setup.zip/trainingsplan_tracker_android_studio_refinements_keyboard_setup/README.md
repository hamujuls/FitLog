# Trainingsplan Tracker

Android-Studio-Projekt für den Trainingsplan Tracker.

Aktuelle Änderungen:
- Daten-Karte in den Einstellungen bereinigt.
- Export erstellt eine JSON-Backup-Datei.
- Backup-Import öffnet eine Backup-Datei über die Android-Dateiauswahl.
- Manuelle Buttons „Daten dieser ID laden“ und „Jetzt in Firebase speichern“ entfernt.
- Benutzer-ID bleibt nicht direkt editierbar; Änderung läuft über Bestätigung und Eingabe-Popup.
- Nach Änderung der Benutzer-ID synchronisiert die App automatisch mit Firebase.
- Keine sichtbare Meldung „In Firebase gespeichert“ mehr.

- Export öffnet jetzt den Android-Dateimanager über „Speichern unter“, damit der Speicherort ausgewählt werden kann.


Update: Hinweis-Felder in den Einstellungen starten einzeilig und wachsen automatisch mit mehr Text.

Update: In den Einstellungen wurde unten ein Lizenzhinweis zu CC BY-NC-SA 4.0 und ein Link zum GitHub-Repository ergänzt.
