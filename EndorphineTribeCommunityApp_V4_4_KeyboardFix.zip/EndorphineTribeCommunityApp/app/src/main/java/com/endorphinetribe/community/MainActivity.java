package com.endorphinetribe.community;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.content.Intent;
import android.content.Context;
import android.content.ContentResolver;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final int PICK_FILE_REQUEST = 7711;

    private final String[] channels = {
            "Trainingsmeetups", "Ausdauer", "Kraft", "Ernährung", "Literatur", "Recovery", "Equipment", "Off Topic"
    };

    private final String[] channelSubtitles = {
            "Gemeinsam trainieren, Laufgruppen, Gym-Sessions & spontane Meetups",
            "Laufen, Rad, Schwimmen, Ausdauerpläne, Events & Pace-Talk",
            "Hypertrophie, Power, Technik, Progression & Gym-Logs",
            "Fueling, Alltagsernährung, Rezepte, Supplements & Meal-Ideen",
            "Bücher, Artikel, Studien, Podcasts & gute Gedanken",
            "Schlaf, Mobility, Regeneration, Verletzungsprävention & Deloads",
            "Schuhe, Wearables, Apps, Bikes, Gym-Gear & Setup-Tipps",
            "Alles, was sonst nirgends reinpasst"
    };

    private SharedPreferences prefs;
    private String activeChannel = "Trainingsmeetups";
    private String pendingFileName = "";
    private String pendingFileUri = "";
    private String pendingMimeType = "";

    private LinearLayout root;
    private LinearLayout messagesList;
    private TextView titleView;
    private TextView subtitleView;
    private TextView attachmentPreview;
    private EditText input;
    private ScrollView chatScroll;

    private final int bgTop = Color.rgb(10, 12, 19);
    private final int bgBottom = Color.rgb(22, 24, 34);
    private final int card = Color.rgb(31, 34, 47);
    private final int cardSoft = Color.rgb(39, 43, 58);
    private final int cardStroke = Color.rgb(65, 70, 88);
    private final int accent = Color.rgb(255, 111, 42);
    private final int accent2 = Color.rgb(255, 190, 88);
    private final int green = Color.rgb(91, 229, 161);
    private final int text = Color.rgb(245, 247, 252);
    private final int muted = Color.rgb(166, 172, 190);
    private final int bubbleMine = Color.rgb(50, 56, 75);
    private final int bubbleOther = Color.rgb(30, 34, 48);
    private final int danger = Color.rgb(190, 65, 65);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        prefs = getSharedPreferences("endorphine_tribe_chat_v5", MODE_PRIVATE);
        seedDemoMessagesIfNeeded();
        if (TextUtils.isEmpty(getUserName())) showOnboarding();
        else showHome();
    }

    private void baseRoot(boolean compact) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int topPad = statusBarHeight() + (compact ? dp(10) : dp(18));
        root.setPadding(compact ? dp(12) : dp(18), topPad, compact ? dp(12) : dp(18), compact ? dp(12) : dp(14));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{bgTop, bgBottom});
        root.setBackground(bg);
        setContentView(root);
    }

    private void showOnboarding() {
        baseRoot(false);

        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setGravity(Gravity.CENTER);
        root.addView(wrap, new LinearLayout.LayoutParams(-1, -1));

        LinearLayout cardWrap = cardBox(dp(28), true);
        cardWrap.setPadding(dp(18), dp(18), dp(18), dp(18));
        wrap.addView(cardWrap, new LinearLayout.LayoutParams(-1, -2));

        cardWrap.addView(createWordmarkHeader(), new LinearLayout.LayoutParams(-1, -2));

        TextView headline = textView("Willkommen in deiner Sportcommunity", 22, text, true);
        headline.setPadding(0, dp(16), 0, 0);
        cardWrap.addView(headline);

        TextView intro = textView("Beim ersten Start: bitte gib deinen Namen und optional deinen Vereinsnamen ein.", 14, muted, false);
        intro.setPadding(0, dp(8), 0, dp(14));
        cardWrap.addView(intro);

        EditText nameInput = field("Dein Name");
        cardWrap.addView(nameInput, new LinearLayout.LayoutParams(-1, -2));

        EditText clubInput = field("Vereinsname (optional)");
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, -2);
        clp.setMargins(0, dp(10), 0, 0);
        cardWrap.addView(clubInput, clp);

        TextView save = largeActionButton("Weiter");
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, dp(56));
        slp.setMargins(0, dp(16), 0, 0);
        cardWrap.addView(save, slp);
        save.setOnClickListener(v -> {
            String n = nameInput.getText().toString().trim();
            String club = clubInput.getText().toString().trim();
            if (TextUtils.isEmpty(n)) {
                Toast.makeText(this, "Bitte gib deinen Namen ein.", Toast.LENGTH_SHORT).show();
                return;
            }
            prefs.edit().putString("user_name", n).putString("club_name", club).apply();
            showHome();
        });
    }

    private void showHome() {
        baseRoot(false);

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, -1));

        LinearLayout brandCard = cardBox(dp(28), true);
        brandCard.setGravity(Gravity.CENTER_HORIZONTAL);
        brandCard.setPadding(dp(18), dp(18), dp(18), dp(18));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, -2);
        blp.setMargins(0, 0, 0, dp(16));

        brandCard.addView(createWordmarkHeader(), new LinearLayout.LayoutParams(-1, -2));

        TextView sub = textView("Community · Chat · Meetups · Wissen", 14, muted, false);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(10), 0, 0);
        brandCard.addView(sub);
        content.addView(brandCard, blp);

        for (int i = 0; i < channels.length; i++) {
            final String room = channels[i];
            final String description = channelSubtitles[i];
            final String icon = iconFor(room);
            content.addView(roomButton(room, description, icon, v -> showChat(room)));
        }
        content.addView(roomButton("Einstellungen", "Profil, Vereinsname und App zurücksetzen", "⚙", v -> showSettings()));
    }

    private View roomButton(String room, String description, String icon, View.OnClickListener listener) {
        LinearLayout box = cardBox(dp(22), false);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(14), dp(14), dp(14), dp(14));
        box.setClickable(true);
        box.setOnClickListener(listener);

        TextView ico = textView(icon, 25, text, true);
        ico.setGravity(Gravity.CENTER);
        ico.setBackground(gradientRound(dp(18)));
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(54), dp(54));
        ilp.setMargins(0, 0, dp(12), 0);
        box.addView(ico, ilp);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        TextView name = textView(room, 18, text, true);
        TextView desc = textView(description, 13, muted, false);
        desc.setPadding(0, dp(4), 0, 0);
        texts.addView(name);
        texts.addView(desc);
        box.addView(texts, new LinearLayout.LayoutParams(0, -2, 1));

        TextView arrow = textView("›", 34, accent2, true);
        arrow.setGravity(Gravity.CENTER);
        box.addView(arrow, new LinearLayout.LayoutParams(dp(28), dp(54)));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));
        box.setLayoutParams(lp);
        return box;
    }

    private void showSettings() {
        baseRoot(false);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(0, 0, 0, dp(12));

        TextView back = smallRoundButton("‹");
        back.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
        back.setOnClickListener(v -> showHome());
        top.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));

        TextView title = textView("Einstellungen", 23, text, true);
        title.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC));
        title.setGravity(Gravity.CENTER);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));

        Space sp = new Space(this);
        top.addView(sp, new LinearLayout.LayoutParams(dp(48), dp(48)));
        root.addView(top);

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, -1));

        LinearLayout profileCard = cardBox(dp(24), true);
        profileCard.setPadding(dp(16), dp(16), dp(16), dp(16));
        content.addView(profileCard, new LinearLayout.LayoutParams(-1, -2));

        TextView t1 = textView("Profil", 18, text, true);
        profileCard.addView(t1);
        TextView t2 = textView("Diese Daten werden im Chat für deine eigenen Nachrichten verwendet.", 13, muted, false);
        t2.setPadding(0, dp(6), 0, dp(12));
        profileCard.addView(t2);

        EditText nameInput = field("Name");
        nameInput.setText(getUserName());
        profileCard.addView(nameInput, new LinearLayout.LayoutParams(-1, -2));

        EditText clubInput = field("Vereinsname (optional)");
        clubInput.setText(getClubName());
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, -2);
        clp.setMargins(0, dp(10), 0, 0);
        profileCard.addView(clubInput, clp);

        TextView saveProfile = largeActionButton("Profil speichern");
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, dp(54));
        slp.setMargins(0, dp(14), 0, 0);
        profileCard.addView(saveProfile, slp);
        saveProfile.setOnClickListener(v -> {
            String n = nameInput.getText().toString().trim();
            String club = clubInput.getText().toString().trim();
            if (TextUtils.isEmpty(n)) {
                Toast.makeText(this, "Bitte gib deinen Namen ein.", Toast.LENGTH_SHORT).show();
                return;
            }
            prefs.edit().putString("user_name", n).putString("club_name", club).apply();
            Toast.makeText(this, "Profil gespeichert.", Toast.LENGTH_SHORT).show();
        });

        LinearLayout resetCard = cardBox(dp(24), false);
        resetCard.setPadding(dp(16), dp(16), dp(16), dp(16));
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-1, -2);
        rlp.setMargins(0, dp(12), 0, dp(12));
        content.addView(resetCard, rlp);

        TextView rt = textView("App zurücksetzen", 18, text, true);
        resetCard.addView(rt);
        TextView rd = textView("Löscht Namen, Vereinsname und alle lokal gespeicherten Chats auf diesem Gerät.", 13, muted, false);
        rd.setPadding(0, dp(6), 0, dp(12));
        resetCard.addView(rd);

        TextView reset = dangerButton("Alles zurücksetzen");
        resetCard.addView(reset, new LinearLayout.LayoutParams(-1, dp(54)));
        reset.setOnClickListener(v -> {
            prefs.edit().clear().apply();
            pendingFileName = "";
            pendingFileUri = "";
            pendingMimeType = "";
            Toast.makeText(this, "App wurde zurückgesetzt.", Toast.LENGTH_SHORT).show();
            showOnboarding();
        });
    }

    private void showChat(String channel) {
        activeChannel = channel;
        pendingFileName = "";
        pendingFileUri = "";
        pendingMimeType = "";
        baseRoot(true);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(0, 0, 0, dp(8));

        TextView back = smallRoundButton("‹");
        back.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
        back.setOnClickListener(v -> showHome());
        top.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));

        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER);
        center.setPadding(dp(8), 0, dp(8), 0);

        titleView = textView(activeChannel, 23, text, true);
        titleView.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC));
        titleView.setGravity(Gravity.CENTER);
        center.addView(titleView);

        subtitleView = textView(channelSubtitles[indexOf(activeChannel)], 12, muted, false);
        subtitleView.setGravity(Gravity.CENTER);
        subtitleView.setSingleLine(true);
        subtitleView.setEllipsize(TextUtils.TruncateAt.END);
        center.addView(subtitleView);

        top.addView(center, new LinearLayout.LayoutParams(0, -2, 1));

        Space rightSpacer = new Space(this);
        top.addView(rightSpacer, new LinearLayout.LayoutParams(dp(48), dp(48)));
        root.addView(top);

        chatScroll = new ScrollView(this);
        messagesList = new LinearLayout(this);
        messagesList.setOrientation(LinearLayout.VERTICAL);
        messagesList.setPadding(0, dp(8), 0, dp(8));
        chatScroll.addView(messagesList);
        root.addView(chatScroll, new LinearLayout.LayoutParams(-1, 0, 1));

        attachmentPreview = textView("", 13, accent2, true);
        attachmentPreview.setVisibility(View.GONE);
        attachmentPreview.setPadding(dp(12), dp(8), dp(12), dp(8));
        attachmentPreview.setBackground(round(Color.rgb(54, 45, 35), dp(14), Color.rgb(92, 70, 46), dp(1)));
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-1, -2);
        alp.setMargins(0, 0, 0, dp(6));
        root.addView(attachmentPreview, alp);

        LinearLayout composerWrap = new LinearLayout(this);
        composerWrap.setOrientation(LinearLayout.HORIZONTAL);
        composerWrap.setGravity(Gravity.BOTTOM);
        composerWrap.setPadding(0, dp(8), 0, 0);

        TextView attach = floatingAttachButton();
        attach.setOnClickListener(v -> openFilePicker());
        composerWrap.addView(attach, new LinearLayout.LayoutParams(dp(54), dp(54)));

        LinearLayout inputShell = new LinearLayout(this);
        inputShell.setOrientation(LinearLayout.HORIZONTAL);
        inputShell.setGravity(Gravity.CENTER_VERTICAL);
        inputShell.setPadding(dp(12), dp(4), dp(5), dp(4));
        inputShell.setBackground(round(card, dp(24), cardStroke, dp(1)));

        input = new EditText(this);
        input.setHint("Nachricht schreiben …");
        input.setHintTextColor(muted);
        input.setTextColor(text);
        input.setTextSize(15);
        input.setSingleLine(false);
        input.setMinLines(1);
        input.setMaxLines(4);
        input.setPadding(0, dp(6), dp(8), dp(6));
        input.setBackgroundColor(Color.TRANSPARENT);
        input.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus && chatScroll != null) {
                chatScroll.postDelayed(() -> chatScroll.fullScroll(View.FOCUS_DOWN), 250);
            }
        });
        inputShell.addView(input, new LinearLayout.LayoutParams(0, -2, 1));

        TextView send = sendButton();
        send.setOnClickListener(v -> sendMessage());
        inputShell.addView(send, new LinearLayout.LayoutParams(dp(44), dp(44)));

        LinearLayout.LayoutParams shellLp = new LinearLayout.LayoutParams(0, -2, 1);
        shellLp.setMargins(dp(8), 0, 0, 0);
        composerWrap.addView(inputShell, shellLp);
        root.addView(composerWrap);

        renderMessages();
    }

    private void openFilePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, PICK_FILE_REQUEST);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                final int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                getContentResolver().takePersistableUriPermission(uri, flags);
            } catch (Exception ignored) {}
            pendingFileUri = uri.toString();
            pendingFileName = getFileName(uri);
            pendingMimeType = getMimeType(uri);
            String kind = isImage(pendingMimeType, pendingFileName) ? "Bild" : "Datei";
            attachmentPreview.setText(kind + " bereit zum Senden: " + pendingFileName + "   ✕");
            attachmentPreview.setVisibility(View.VISIBLE);
            attachmentPreview.setOnClickListener(v -> clearAttachment());
        }
    }

    private void clearAttachment() {
        pendingFileName = "";
        pendingFileUri = "";
        pendingMimeType = "";
        attachmentPreview.setVisibility(View.GONE);
    }

    private void sendMessage() {
        String msg = input.getText().toString().trim();
        if (TextUtils.isEmpty(msg) && TextUtils.isEmpty(pendingFileName)) return;
        try {
            JSONArray arr = getMessages(activeChannel);
            JSONObject obj = new JSONObject();
            obj.put("author", getUserName());
            obj.put("club", getClubName());
            obj.put("time", new SimpleDateFormat("dd.MM. HH:mm", Locale.getDefault()).format(new Date()));
            obj.put("text", msg);
            obj.put("fileName", pendingFileName);
            obj.put("fileUri", pendingFileUri);
            obj.put("mimeType", pendingMimeType);
            obj.put("mine", true);
            arr.put(obj);
            prefs.edit().putString(key(activeChannel), arr.toString()).apply();
        } catch (Exception ignored) {}
        input.setText("");
        clearAttachment();
        hideKeyboard();
        renderMessages();
    }

    private void renderMessages() {
        if (messagesList == null) return;
        messagesList.removeAllViews();
        JSONArray arr = getMessages(activeChannel);
        if (arr.length() == 0) {
            LinearLayout empty = cardBox(dp(24), true);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(18), dp(30), dp(18), dp(30));
            TextView e1 = textView(iconFor(activeChannel), 42, text, true);
            e1.setGravity(Gravity.CENTER);
            TextView e2 = textView("Noch ruhig hier", 22, text, true);
            e2.setGravity(Gravity.CENTER);
            TextView e3 = textView("Starte den Austausch mit einer Nachricht, einem Bild, einer Datei oder einer Meetup-Idee.", 15, muted, false);
            e3.setGravity(Gravity.CENTER);
            e3.setPadding(0, dp(8), 0, 0);
            empty.addView(e1);
            empty.addView(e2);
            empty.addView(e3);
            LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(-1, -2);
            elp.setMargins(0, dp(14), 0, 0);
            messagesList.addView(empty, elp);
            return;
        }

        for (int i = 0; i < arr.length(); i++) {
            try { messagesList.addView(messageRow(arr.getJSONObject(i))); } catch (Exception ignored) {}
        }
        chatScroll.postDelayed(() -> chatScroll.fullScroll(View.FOCUS_DOWN), 80);
    }

    private View messageRow(JSONObject obj) throws Exception {
        boolean mine = obj.optBoolean("mine", true);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(mine ? Gravity.RIGHT : Gravity.LEFT);
        row.setPadding(0, 0, 0, dp(10));

        LinearLayout bubble = new LinearLayout(this);
        bubble.setOrientation(LinearLayout.VERTICAL);
        bubble.setPadding(dp(13), dp(10), dp(13), dp(10));
        bubble.setBackground(round(mine ? bubbleMine : bubbleOther, dp(19), mine ? Color.rgb(73, 80, 102) : Color.rgb(55, 60, 76), dp(1)));
        bubble.setElevation(dp(2));

        LinearLayout metaRow = new LinearLayout(this);
        metaRow.setOrientation(LinearLayout.HORIZONTAL);
        metaRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView nameView = textView(mine ? getUserName() : obj.optString("author", "Tribe"), 11, mine ? accent2 : green, true);
        metaRow.addView(nameView);

        String club = mine ? getClubName() : obj.optString("club", "");
        if (!TextUtils.isEmpty(club)) {
            TextView clubView = textView("  " + club, 9, muted, false);
            metaRow.addView(clubView);
        }

        TextView timeView = textView("  ·  " + obj.optString("time", ""), 10, muted, false);
        metaRow.addView(timeView);
        bubble.addView(metaRow);

        String msg = obj.optString("text", "");
        if (!TextUtils.isEmpty(msg)) {
            TextView body = textView(msg, 15, text, false);
            body.setPadding(0, dp(5), 0, 0);
            bubble.addView(body);
        }

        String file = obj.optString("fileName", "");
        String uri = obj.optString("fileUri", "");
        String mimeType = obj.optString("mimeType", "");
        if (!TextUtils.isEmpty(file) && !TextUtils.isEmpty(uri)) {
            if (isImage(mimeType, file)) {
                FrameLayout imageCard = new FrameLayout(this);
                imageCard.setPadding(dp(2), dp(2), dp(2), dp(2));
                imageCard.setBackground(round(Color.rgb(22, 25, 36), dp(16), Color.rgb(71, 77, 96), dp(1)));

                ImageView imageView = new ImageView(this);
                imageView.setAdjustViewBounds(true);
                imageView.setMaxHeight(dp(300));
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView.setImageURI(Uri.parse(uri));
                imageCard.addView(imageView, new FrameLayout.LayoutParams(-1, dp(210)));

                TextView expand = textView("⤢", 20, Color.WHITE, true);
                expand.setGravity(Gravity.CENTER);
                expand.setBackground(round(Color.argb(130, 0, 0, 0), dp(16), Color.TRANSPARENT, 0));
                FrameLayout.LayoutParams expLp = new FrameLayout.LayoutParams(dp(34), dp(34), Gravity.RIGHT | Gravity.TOP);
                expLp.setMargins(0, dp(8), dp(8), 0);
                imageCard.addView(expand, expLp);

                LinearLayout.LayoutParams imgLp = new LinearLayout.LayoutParams(-1, -2);
                imgLp.setMargins(0, dp(10), 0, 0);
                bubble.addView(imageCard, imgLp);

                TextView fileLabel = textView("🖼  " + file, 12, muted, true);
                fileLabel.setPadding(0, dp(7), 0, 0);
                bubble.addView(fileLabel);
                imageCard.setOnClickListener(v -> showImageFullscreen(uri, file));
            } else {
                TextView fileView = textView("📎  " + file, 14, green, true);
                fileView.setPadding(dp(10), dp(8), dp(10), dp(8));
                fileView.setBackground(round(Color.rgb(30, 57, 47), dp(14), Color.rgb(72, 118, 94), dp(1)));
                LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(-1, -2);
                flp.setMargins(0, dp(9), 0, 0);
                bubble.addView(fileView, flp);
                fileView.setOnClickListener(v -> openStoredFile(uri));
            }
        }

        int bubbleWidth = (int)(getResources().getDisplayMetrics().widthPixels * 0.82f);
        LinearLayout.LayoutParams bLp = new LinearLayout.LayoutParams(bubbleWidth, -2);
        row.addView(bubble, bLp);

        return row;
    }

    private LinearLayout createWordmarkHeader() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setGravity(Gravity.CENTER_HORIZONTAL);

        ImageView logoView = new ImageView(this);
        logoView.setImageResource(R.drawable.et_header_logo);
        logoView.setAdjustViewBounds(true);
        logoView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        wrap.addView(logoView, lp);

        return wrap;
    }

    private void showImageFullscreen(String uri, String label) {
        baseRoot(true);
        root.setPadding(dp(10), statusBarHeight() + dp(10), dp(10), dp(12));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setOrientation(LinearLayout.HORIZONTAL);

        TextView back = smallRoundButton("‹");
        back.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
        back.setOnClickListener(v -> showChat(activeChannel));
        top.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));

        TextView title = textView(label == null ? "Bild" : label, 15, text, true);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setGravity(Gravity.CENTER);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));

        TextView open = smallRoundButton("↗");
        open.setTextSize(TypedValue.COMPLEX_UNIT_SP, 21);
        open.setOnClickListener(v -> openStoredFile(uri));
        top.addView(open, new LinearLayout.LayoutParams(dp(48), dp(48)));
        root.addView(top);

        FrameLayout frame = new FrameLayout(this);
        frame.setPadding(0, dp(10), 0, 0);
        ImageView img = new ImageView(this);
        img.setImageURI(Uri.parse(uri));
        img.setAdjustViewBounds(true);
        img.setScaleType(ImageView.ScaleType.FIT_CENTER);
        frame.addView(img, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        root.addView(frame, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(muted);
        e.setTextColor(text);
        e.setTextSize(15);
        e.setPadding(dp(14), dp(12), dp(14), dp(12));
        e.setBackground(round(cardSoft, dp(18), cardStroke, dp(1)));
        return e;
    }

    private TextView avatar(String name, boolean mine) {
        String initials = "ET";
        if (!TextUtils.isEmpty(name)) {
            String[] parts = name.trim().split("\\s+");
            if (parts.length >= 2) initials = (parts[0].substring(0,1) + parts[1].substring(0,1)).toUpperCase(Locale.getDefault());
            else initials = name.substring(0, 1).toUpperCase(Locale.getDefault());
        }
        TextView v = textView(initials, 12, Color.WHITE, true);
        v.setGravity(Gravity.CENTER);
        v.setBackground(mine ? gradientRound(dp(19)) : round(Color.rgb(54, 61, 82), dp(19), Color.rgb(88, 94, 116), dp(1)));
        return v;
    }

    private TextView smallRoundButton(String s) {
        TextView v = textView(s, 18, text, true);
        v.setGravity(Gravity.CENTER);
        v.setBackground(round(cardSoft, dp(18), cardStroke, dp(1)));
        v.setClickable(true);
        return v;
    }

    private TextView floatingAttachButton() {
        TextView v = textView("＋", 26, Color.WHITE, true);
        v.setGravity(Gravity.CENTER);
        v.setBackground(gradientRound(dp(27)));
        v.setClickable(true);
        v.setElevation(dp(6));
        return v;
    }

    private TextView sendButton() {
        TextView v = textView("➤", 21, Color.WHITE, true);
        v.setGravity(Gravity.CENTER);
        v.setBackground(gradientRound(dp(22)));
        v.setClickable(true);
        v.setElevation(dp(3));
        return v;
    }

    private TextView largeActionButton(String textLabel) {
        TextView v = textView(textLabel, 16, Color.WHITE, true);
        v.setGravity(Gravity.CENTER);
        v.setBackground(gradientRound(dp(20)));
        v.setClickable(true);
        v.setElevation(dp(3));
        return v;
    }

    private TextView dangerButton(String textLabel) {
        TextView v = textView(textLabel, 16, Color.WHITE, true);
        v.setGravity(Gravity.CENTER);
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{danger, Color.rgb(224, 86, 86)});
        d.setCornerRadius(dp(20));
        v.setBackground(d);
        v.setClickable(true);
        v.setElevation(dp(3));
        return v;
    }

    private void openStoredFile(String uriString) {
        if (TextUtils.isEmpty(uriString)) return;
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(uriString));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Datei kann auf diesem Gerät nicht geöffnet werden.", Toast.LENGTH_SHORT).show();
        }
    }

    private JSONArray getMessages(String c) {
        try { return new JSONArray(prefs.getString(key(c), "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private String getFileName(Uri uri) {
        String result = null;
        if (ContentResolver.SCHEME_CONTENT.equals(uri.getScheme())) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (index >= 0) result = cursor.getString(index);
                }
            } catch (Exception ignored) {}
        }
        if (result == null) {
            result = uri.getLastPathSegment();
            if (result == null) result = "Anhang";
        }
        return result;
    }

    private String getMimeType(Uri uri) {
        try {
            String type = getContentResolver().getType(uri);
            return type == null ? "" : type;
        } catch (Exception e) {
            return "";
        }
    }

    private boolean isImage(String mimeType, String fileName) {
        if (!TextUtils.isEmpty(mimeType) && mimeType.startsWith("image/")) return true;
        String lower = fileName == null ? "" : fileName.toLowerCase(Locale.getDefault());
        return lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png") || lower.endsWith(".webp") || lower.endsWith(".gif") || lower.endsWith(".bmp");
    }

    private LinearLayout cardBox(int radius, boolean accentBorder) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(round(card, radius, accentBorder ? Color.rgb(89, 69, 60) : cardStroke, dp(1)));
        box.setElevation(dp(3));
        return box;
    }

    private TextView textView(String s, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        v.setTextColor(color);
        v.setIncludeFontPadding(true);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private GradientDrawable round(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        if (strokeWidth > 0) d.setStroke(strokeWidth, strokeColor);
        return d;
    }

    private GradientDrawable gradientRound(int radius) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{accent, accent2});
        d.setCornerRadius(radius);
        return d;
    }

    private int statusBarHeight() {
        int result = 0;
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) result = getResources().getDimensionPixelSize(resourceId);
        return result;
    }

    private void seedDemoMessagesIfNeeded() {
        boolean seeded = prefs.getBoolean("seeded_demo_v5", false);
        if (seeded) return;
        try {
            JSONArray arr = new JSONArray();

            JSONObject a = new JSONObject();
            a.put("author", "Michi");
            a.put("club", "Crew");
            a.put("time", "Heute 09:12");
            a.put("text", "Wer ist diese Woche bei einer lockeren Kraftsession dabei?");
            a.put("mine", false);
            arr.put(a);

            JSONObject b = new JSONObject();
            b.put("author", "Du");
            b.put("club", "");
            b.put("time", "Heute 09:18");
            b.put("text", "Ich wäre dabei. Oberkörper + danach kurzer Mobility-Block?");
            b.put("mine", true);
            arr.put(b);

            prefs.edit().putString(key("Trainingsmeetups"), arr.toString()).putBoolean("seeded_demo_v5", true).apply();
        } catch (Exception ignored) {}
    }

    private String getUserName() { return prefs.getString("user_name", "").trim(); }
    private String getClubName() { return prefs.getString("club_name", "").trim(); }

    private String key(String c) { return "channel_json_" + c.replace(" ", "_"); }
    private int indexOf(String c) { for (int i=0;i<channels.length;i++) if (channels[i].equals(c)) return i; return 0; }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private String iconFor(String c) {
        if (c.equals("Trainingsmeetups")) return "⚡";
        if (c.equals("Ausdauer")) return "🏃";
        if (c.equals("Kraft")) return "💪";
        if (c.equals("Ernährung")) return "🥗";
        if (c.equals("Literatur")) return "📚";
        if (c.equals("Recovery")) return "🧘";
        if (c.equals("Equipment")) return "🎒";
        return "🌙";
    }

    private void hideKeyboard() {
        try { ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(), 0); } catch(Exception ignored) {}
    }
}
