# Endorphine Tribe Community App – V4.4 Keyboard Fix

Änderung:
- Chat-Eingabefeld bleibt jetzt oberhalb der Tastatur sichtbar
- Android `windowSoftInputMode="adjustResize"` gesetzt
- zusätzlicher Fokus-Scroll im Chat, damit die letzte Nachricht und das Textfeld sichtbar bleiben

Bisherige Features bleiben erhalten:
- Logo oben in Hauptansicht und Onboarding
- Einstellungen unter den Chatrooms
- App zurücksetzen
- Name + Vereinsname beim ersten Start
- Vereinsname klein neben dem Benutzernamen
- breite Chat-Bubbles
- keine Avatar-Kreise neben den Chat-Bubbles
- Datei-Upload
- Bilder direkt im Chat
- Bild-Vollansicht
